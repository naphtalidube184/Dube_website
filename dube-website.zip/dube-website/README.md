# Naphtali T. Dube – personal website

Plain HTML site. No build step. Hosted on Netlify, edited with Pages CMS.

## Go live (one time, about 15 minutes)

1. **GitHub**: create a new public repository named `dube-website`. Click "uploading an existing file", drag in everything from this folder (including `.pages.yml`), and commit.
   - Hidden files: if `.pages.yml` doesn't show on your computer, turn on "show hidden files", or create it on GitHub with "Add file > Create new file" and paste its contents.
2. **Netlify**: sign in at netlify.com with GitHub. "Add new site" > "Import an existing project" > pick `dube-website`. Leave build command empty, publish directory `.`. Deploy.
3. **Site name**: in Netlify, Site configuration > Change site name, e.g. `ntdube` → `ntdube.netlify.app`. A custom domain (like ntdube.com, about $12/year) can be added later under Domain management.
4. **Pages CMS**: go to app.pagescms.org, sign in with GitHub, install it on the `dube-website` repo. You'll see: Contact and resume, Publications, Projects, Extra tools.
5. In Pages CMS, open **Contact and resume**, add your email and LinkedIn, upload your resume PDF, and save. Netlify updates the live site in about a minute.

## Adding things later

- **New publication or project**: Pages CMS > Publications or Projects > add an item > Save. The first item in the list shows first.
- **New calculator/tool**: copy `tools/_template.html` to e.g. `tools/haul-truck-productivity.html`, build the tool in it (or ask Claude to), upload it to the `tools` folder on GitHub, then add it in Pages CMS > Extra tools with the link `tools/haul-truck-productivity.html`.
- The four built-in calculators (cutoff grade, NPV/IRR, stripping ratio, planar FoS) live inside `index.html`.

## Files

- `index.html` – the whole page and built-in calculators
- `content/*.json` – the editable content (contact, publications, projects, extra tools)
- `.pages.yml` – tells Pages CMS what can be edited
- `media/` – uploaded files such as your resume PDF
- `tools/` – standalone tool pages
